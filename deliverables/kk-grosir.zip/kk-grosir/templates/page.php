<?php defined('ABSPATH') || exit; ?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php wp_head(); ?>
</head>
<body <?php body_class('kkg-page'); ?>>
<?php wp_body_open(); ?>
<?php echo kkg_render(); ?>
<?php wp_footer(); ?>
</body>
</html>
